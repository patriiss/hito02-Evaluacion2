(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-header>\n  <ion-toolbar>      \n    <div class=\"title-block\">\n      <div class=\"heading\">Mi agenda</div>\n    </div>\n  </ion-toolbar> \n</ion-header>     \n<ion-content>\n  <ion-list>\n    <ion-list-header class=\"fondo\" >\n      <ion-label>Notas</ion-label>\n    </ion-list-header>\n    <ion-item *ngFor=\"let note of (notes | async)\">\n      <ion-thumbnail slot=\"start\" class=\"imagen\">\n        \n      </ion-thumbnail>\n      <ion-label>\n        <h2>{{note.title}}</h2>\n        <p>{{note.content}}</p>\n      </ion-label>\n      <ion-button class=\"boton\" fill=\"outline\" color=\"#FF005A\" slot=\"end\" [routerLink]=\"'/view-note/'+note.id\">Ver</ion-button>\n    </ion-item>\n    \n  </ion-list>\n  <ion-fab vertical=\"bottom\"  horizontal=\"end\" slot=\"fixed\" >\n    <ion-fab-button color=\"dark\" [routerLink]=\"'/add-note'\">\n      <ion-icon class=\"botonn\"  name=\"add\" ></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n  \n</ion-content>\n<div class=\"link\">\n  <a href=\"https://github.com/patriiss/hito02-Evaluacion2\" class=\"link2\">Github</a>\n</div>");

/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".title-block {\n  position: relative;\n  margin: 0;\n  padding: 0;\n  height: 80px;\n}\n\n.title-block .heading {\n  font-size: 26px;\n  color: #FF005A;\n  text-align: center;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  -webkit-transform: translate(-50%, -50%);\n          transform: translate(-50%, -50%);\n  font-family: \"Arial Black\";\n}\n\n.imagen {\n  background-image: url('icono.png');\n  background-repeat: no-repeat;\n}\n\n.fondo {\n  color: #9F9C9D;\n}\n\n.boton {\n  color: #FF005A;\n}\n\n.botonn {\n  color: #FF005A;\n}\n\n.link {\n  color: #FF005A;\n  text-align: center;\n  background-color: #1D1D1D;\n  height: 6%;\n  padding: 1.5%;\n}\n\n.link2 {\n  text-align: center;\n  color: #FF005A;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9DOlxcZGVzYXJyb2xsb0ludGVyZmFjZXNcXEhJVE9TXFwyRVZcXGNydWRmaXJlYmFzZS9zcmNcXGFwcFxcaG9tZVxcaG9tZS5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBRUEsWUFBQTtBQ0FGOztBREdBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSx3Q0FBQTtVQUFBLGdDQUFBO0VBQ0EsMEJBQUE7QUNBRjs7QURHQTtFQUNFLGtDQUFBO0VBQ0EsNEJBQUE7QUNBRjs7QURHQTtFQUNFLGNBQUE7QUNBRjs7QURHQTtFQUNFLGNBQUE7QUNBRjs7QURJQTtFQUNFLGNBQUE7QUNERjs7QURJQTtFQUNFLGNBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7QUNERjs7QURHQTtFQUNFLGtCQUFBO0VBQ0EsY0FBQTtBQ0FGIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aXRsZS1ibG9ja3tcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW46IDA7XG4gIHBhZGRpbmc6IDA7XG4gIC8vYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2ltZy9iZy5qcGdcIik7XG4gIGhlaWdodDogODBweDtcbn1cblxuLnRpdGxlLWJsb2NrIC5oZWFkaW5ne1xuICBmb250LXNpemU6IDI2cHg7XG4gIGNvbG9yOiAjRkYwMDVBO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGZvbnQtZmFtaWx5OiBcIkFyaWFsIEJsYWNrXCJcbn1cblxuLmltYWdlbntcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2ltZy9pY29uby5wbmdcIik7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG59XG5cbi5mb25kb3tcbiAgY29sb3I6ICM5RjlDOUQ7XG59XG5cbi5ib3RvbntcbiAgY29sb3I6ICNGRjAwNUE7XG4gIFxufVxuXG4uYm90b25ue1xuICBjb2xvcjojRkYwMDVBO1xufVxuXG4ubGlua3tcbiAgY29sb3I6I0ZGMDA1QTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMUQxRDFEO1xuICBoZWlnaHQ6IDYlO1xuICBwYWRkaW5nOiAxLjUlO1xufVxuLmxpbmsye1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiNGRjAwNUE7XG5cbn0iLCIudGl0bGUtYmxvY2sge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG1hcmdpbjogMDtcbiAgcGFkZGluZzogMDtcbiAgaGVpZ2h0OiA4MHB4O1xufVxuXG4udGl0bGUtYmxvY2sgLmhlYWRpbmcge1xuICBmb250LXNpemU6IDI2cHg7XG4gIGNvbG9yOiAjRkYwMDVBO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGZvbnQtZmFtaWx5OiBcIkFyaWFsIEJsYWNrXCI7XG59XG5cbi5pbWFnZW4ge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1nL2ljb25vLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbn1cblxuLmZvbmRvIHtcbiAgY29sb3I6ICM5RjlDOUQ7XG59XG5cbi5ib3RvbiB7XG4gIGNvbG9yOiAjRkYwMDVBO1xufVxuXG4uYm90b25uIHtcbiAgY29sb3I6ICNGRjAwNUE7XG59XG5cbi5saW5rIHtcbiAgY29sb3I6ICNGRjAwNUE7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzFEMUQxRDtcbiAgaGVpZ2h0OiA2JTtcbiAgcGFkZGluZzogMS41JTtcbn1cblxuLmxpbmsyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0ZGMDA1QTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_firebase_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/firebase.service */ "./src/app/services/firebase.service.ts");



let HomePage = class HomePage {
    constructor(fbService) {
        this.fbService = fbService;
    }
    ngOnInit() {
        this.notes = this.fbService.getNotes();
    }
};
HomePage.ctorParameters = () => [
    { type: _services_firebase_service__WEBPACK_IMPORTED_MODULE_2__["FirebaseService"] }
];
HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_firebase_service__WEBPACK_IMPORTED_MODULE_2__["FirebaseService"]])
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map