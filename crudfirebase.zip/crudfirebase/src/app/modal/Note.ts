export interface Note {
    id?: any;
    title: String;
    content: String;
    createdAt: any;
}
