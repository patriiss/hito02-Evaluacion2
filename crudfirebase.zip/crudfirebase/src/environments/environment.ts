// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDRYanI6jm8nDech1X0HKxVoVkVCoUz9pU",
    authDomain: "patri-hito02.firebaseapp.com",
    databaseURL: "https://patri-hito02.firebaseio.com",
    projectId: "patri-hito02",
    storageBucket: "patri-hito02.appspot.com",
    messagingSenderId: "681207023252",
    appId: "1:681207023252:web:b5ef248bd45da47ea35681",
    measurementId: "G-SVXGJTJBBP"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
